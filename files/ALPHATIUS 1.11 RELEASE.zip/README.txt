IMPORTANT INFO FOR BOTH PLAYERS AND SERVER HOSTERS
-This mod was made for Zandronum and DOOM2.wad. It won't work for any other ports or IWADS.
-Please note that it is strongly recommended to play ALPHATIUS using OpenGL as your renderer.
	This can be done by going to Options > Set Video Mode > Renderer and setting it to OpenGL.
	Some older computers cannot use this option and can cause Zandronum to crash on startup.
	Do so at your own risk, or fix/delete your zandronum .ini file if anything goes wrong.
-This mod was designed with its own, built-in maps in mind. Doom II maps were not designed for
	Alphatius's gameplay. Any additional maps added by addons or anything of the sort that are
	designed for Alphatius are okay, but don't be suprised if they don't work as well, or break
	the game.
-This mod was designed to be a STANDALONE mod. If you try to run this with other mods,
	there's no guarantee that it will work. This includes map packs, weapon mods,
	other standalone mods, etc. Be reasonable if you want to ask me to make it compatible
	with a certain mod, because if you mention any of these kinds of mods, I will most likely say "no".
-This mod was developed by hiimaura. However, many of the resources came from many different sources.
	The credits can be found in CREDITS.txt, or alongside their respective resources in the .pk3 file.
-Display stats command only works in a server setting if the server is correctly configured. See below for
	correctly configuring a server.
-To enable super weapons, use "+alph_allowsuperweapons true". Weapon stay is strongly
	discouraged when using this. Use "sv_weaponstay false" to disable weapon stay.
-This mod was designed with Deathmatch in mind. Any other gamemode is risky and not guaranteed to
	work or be balanced. Support for other gamemodes are likely to come soon (I'm already working
	on duel levels and considering CTF maps too). There is also a Duel map in the pk3 if you want to use
	it, but it may not work as well, and it's the only one, so it may get stale quickly.

IMPORTANT INFO FOR SETTING UP A SERVER
-To allow Database Functionality, server hosters should use "+authhostname auth.zandronum.com:16666"
	as a command line parameters. Once the server is up, use "databasefile (name here)" to create/load
	the database file. This allows players to keep track of their stats and "show them off"
	(in classic competitve style) when they kill another player.
	See this link for more info: https://zandronum.com/forum/viewtopic.php?t=6993

KNOWN ISSUES
-None known yet.

DISCORD SERVER:
https://discord.gg/EwycBVm

CONTACT:
The best way to reach me is through the above discord server. It has everything you need
for suggestions, bugs, finding friends, etc.


